<?php
/****************************************************************************************
* LiveZilla livezilla.php
* 
* Copyright 2014 LiveZilla GmbH
* All rights reserved.
* LiveZilla is a registered trademark.
* 
* Improper changes to this file may cause critical errors.
***************************************************************************************/ 
require("./chat.php");
?>
